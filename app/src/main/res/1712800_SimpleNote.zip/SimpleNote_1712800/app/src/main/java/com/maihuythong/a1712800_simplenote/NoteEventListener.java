package com.maihuythong.a1712800_simplenote;

interface NoteEventListener {

    void onNoteClick(Note note);

}
